import _ from 'lodash';
import './index.css';
import mainImage from './R.png';
